const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

const dbFile = path.join(__dirname, 'data.db');
const db = new sqlite3.Database(dbFile);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, firstName TEXT, lastName TEXT)`);
  db.run(`CREATE TABLE IF NOT EXISTS records (uid TEXT PRIMARY KEY, id TEXT, name TEXT, date TEXT, amount REAL, photo TEXT, createdAt TEXT)`);
});

app.get('/api/users', (req, res) => {
  db.all('SELECT * FROM users', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/users', (req, res) => {
  const { id, firstName, lastName } = req.body;
  db.run('INSERT OR REPLACE INTO users(id, firstName, lastName) VALUES(?,?,?)', [id, firstName, lastName], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.get('/api/records', (req, res) => {
  db.all('SELECT * FROM records ORDER BY createdAt DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/records', (req, res) => {
  const { uid, id, name, date, amount, photo } = req.body;
  const createdAt = new Date().toISOString();
  db.run('INSERT INTO records(uid,id,name,date,amount,photo,createdAt) VALUES(?,?,?,?,?,?,?)', [uid, id, name, date, amount, photo, createdAt], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.delete('/api/records/:uid', (req, res) => {
  db.run('DELETE FROM records WHERE uid = ?', [req.params.uid], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Server running on port', PORT));
