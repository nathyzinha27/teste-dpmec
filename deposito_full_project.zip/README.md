# Depósito Site - Full Project (Frontend + Backend)

## Estrutura
- frontend/  (Vite + React + Tailwind)
- backend/   (Express + SQLite)

## Como usar - Frontend
1. Abra terminal em `frontend`:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
2. Abra `http://localhost:5173`

## Como usar - Backend
1. Abra terminal em `backend`:
   ```bash
   cd backend
   npm install
   npm start
   ```
2. Backend rodará em `http://localhost:4000`

## Observações
- Frontend usa `localStorage` por padrão; para integrar ao backend ajuste os endpoints em `src/App.jsx`.
- Troque a senha admin de exemplo antes de usar em produção.
