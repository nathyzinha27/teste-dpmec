import React, { useEffect, useState, useRef } from "react";

// Advanced deposit app (single-file for demo)
const STORAGE_KEYS = {
  RECORDS: "ads_records_v1",
  USERS: "ads_users_v1",
};

const DEFAULT_USERS = {
  "1001": { firstName: "João", lastName: "Silva" },
  "1002": { firstName: "Maria", lastName: "Oliveira" },
  "1003": { firstName: "Carlos", lastName: "Santos" },
};

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function writeJSON(key, v) {
  localStorage.setItem(key, JSON.stringify(v));
}

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

function formatCurrency(n) {
  if (!n && n !== 0) return "R$ 0,00";
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(n));
}

function startOfWeek(d) {
  const date = new Date(d);
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(date.setDate(diff));
}

export default function App() {
  const [users, setUsers] = useState(() => readJSON(STORAGE_KEYS.USERS, DEFAULT_USERS));
  const [records, setRecords] = useState(() => readJSON(STORAGE_KEYS.RECORDS, []));
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const ADMIN_SECRET = "admin123";

  const [entryId, setEntryId] = useState("");
  const [entryName, setEntryName] = useState({ firstName: "", lastName: "" });
  const [entryDate, setEntryDate] = useState(new Date().toISOString().slice(0, 10));
  const [entryAmount, setEntryAmount] = useState("");
  const fileRef = useRef();

  const totalDeposited = records.reduce((s, r) => s + Number(r.amount || 0), 0);

  useEffect(() => writeJSON(STORAGE_KEYS.USERS, users), [users]);
  useEffect(() => writeJSON(STORAGE_KEYS.RECORDS, records), [records]);

  useEffect(() => {
    if (!entryId) return setEntryName({ firstName: "", lastName: "" });
    const u = users[entryId];
    if (u) setEntryName(u);
    else setEntryName({ firstName: "", lastName: "" });
  }, [entryId, users]);

  function handlePhotoUpload(file) {
    return new Promise((res, rej) => {
      if (!file) return res(null);
      const reader = new FileReader();
      reader.onload = () => res(reader.result);
      reader.onerror = rej;
      reader.readAsDataURL(file);
    });
  }

  async function submitEntry(e) {
    e && e.preventDefault();
    if (!entryId) return alert("Informe o ID");
    if (!entryAmount) return alert("Informe o valor depositado");
    const photoData = fileRef.current?.files?.[0] ? await handlePhotoUpload(fileRef.current.files[0]) : null;

    if (!users[entryId]) {
      setUsers((prev) => ({ ...prev, [entryId]: { firstName: "", lastName: "" } }));
    }

    const newRecord = {
      uid: uid(),
      id: entryId,
      name: users[entryId] ? `${users[entryId].firstName} ${users[entryId].lastName}`.trim() : "",
      date: entryDate,
      amount: Number(entryAmount),
      photo: photoData,
      createdAt: new Date().toISOString(),
    };

    setRecords((r) => [newRecord, ...r]);

    setEntryId("");
    setEntryAmount("");
    setEntryDate(new Date().toISOString().slice(0, 10));
    fileRef.current && (fileRef.current.value = "");
    alert(`Depósito registrado com sucesso. Nome: ${newRecord.name || entryId}`);
  }

  function adminLogin() {
    if (adminPassword === ADMIN_SECRET) {
      setIsAdmin(true);
      setAdminPassword("");
    } else alert("Senha de administrador incorreta");
  }

  function adminLogout() {
    setIsAdmin(false);
  }

  function deleteRecord(uidToDelete) {
    if (!confirm("Tem certeza que deseja excluir este registro?")) return;
    setRecords((r) => r.filter((x) => x.uid !== uidToDelete));
  }

  function editRecord(uidToEdit, patch) {
    setRecords((r) => r.map((x) => (x.uid === uidToEdit ? { ...x, ...patch } : x)));
  }

  function updateUser(id, patch) {
    setUsers((u) => ({ ...u, [id]: { ...(u[id] || {}), ...patch } }));
  }

  function removeUser(id) {
    if (!confirm(`Excluir usuário ${id}? Isso não apagará os registros que já existem.`)) return;
    const next = { ...users };
    delete next[id];
    setUsers(next);
  }

  function recordsByWeek() {
    const groups = {};
    records.forEach((r) => {
      const wk = startOfWeek(r.date || r.createdAt).toISOString().slice(0, 10);
      if (!groups[wk]) groups[wk] = [];
      groups[wk].push(r);
    });
    return groups;
  }

  const groups = recordsByWeek();

  function exportCSV() {
    const header = ["uid,ID,Nome,Data,Valor,createdAt"].join("\n");
    const rows = records.map((r) => `${r.uid},${r.id},"${r.name}",${r.date},${r.amount},${r.createdAt}`);
    const csv = [header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `deposits_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6 md:p-12 font-sans">
      <div className="fixed top-4 right-4 bg-white shadow-md rounded-2xl p-3 z-50">
        <div className="text-xs text-gray-500">Depósito total</div>
        <div className="text-lg font-bold">{formatCurrency(totalDeposited)}</div>
      </div>

      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4">Registrar depósito</h2>
          <form onSubmit={submitEntry}>
            <label className="block text-sm text-gray-600">ID</label>
            <input value={entryId} onChange={(e) => setEntryId(e.target.value)} className="w-full p-2 rounded-md border mt-1" placeholder="Ex: 1001" />

            <label className="block text-sm text-gray-600 mt-3">Nome (preenchido automático)</label>
            <input value={`${entryName.firstName || ""} ${entryName.lastName || ""}`.trim()} readOnly className="w-full p-2 rounded-md border mt-1 bg-gray-50" />

            <label className="block text-sm text-gray-600 mt-3">Valor depositado</label>
            <input value={entryAmount} onChange={(e) => setEntryAmount(e.target.value)} type="number" step="0.01" className="w-full p-2 rounded-md border mt-1" placeholder="0.00" />

            <label className="block text-sm text-gray-600 mt-3">Data do depósito</label>
            <input value={entryDate} onChange={(e) => setEntryDate(e.target.value)} type="date" className="w-full p-2 rounded-md border mt-1" />

            <label className="block text-sm text-gray-600 mt-3">Foto (comprovante) — opcional</label>
            <input ref={fileRef} type="file" accept="image/*" className="w-full mt-1" />

            <div className="mt-4 flex gap-2">
              <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md">Enviar</button>
              <button type="button" onClick={() => { setEntryId(""); setEntryAmount(""); fileRef.current && (fileRef.current.value = ""); }} className="px-4 py-2 border rounded-md">Limpar</button>
            </div>
          </form>

          <div className="mt-6 text-sm text-gray-500">
            Ao colocar o ID e o valor, o sistema cria o registro. Administradores podem editar ou excluir registros.
          </div>
        </div>

        <div className="md:col-span-2 bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Registros recentes</h2>
            <div className="flex items-center gap-2">
              <div className="text-sm text-gray-500">Filtrar semana</div>
              <input type="date" onChange={(e) => {}} className="p-1 border rounded-md" />
            </div>
          </div>

          <div className="mt-4 grid gap-3">
            {records.length === 0 && <div className="text-gray-500">Nenhum registro ainda.</div>}
            {records.map((r) => (
              <div key={r.uid} className="flex items-center gap-4 p-3 border rounded-md">
                <div className="w-16 h-12 bg-gray-100 flex items-center justify-center rounded-md overflow-hidden">
                  {r.photo ? <img src={r.photo} alt="comprovante" className="object-cover w-full h-full" /> : <div className="text-xs text-gray-400">Sem foto</div>}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">{r.name || r.id}</div>
                  <div className="text-xs text-gray-500">ID: {r.id} • {new Date(r.date).toLocaleDateString()}</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{formatCurrency(r.amount)}</div>
                  <div className="text-xs text-gray-400">{new Date(r.createdAt).toLocaleString()}</div>
                </div>
                {isAdmin && (
                  <div className="flex gap-2 ml-4">
                    <button onClick={() => { const patch = prompt("Atualizar valor (apenas número)", String(r.amount)); if (patch !== null) { editRecord(r.uid, { amount: Number(patch) }); alert("Valor atualizado."); } }} className="p-2 rounded-md border">Editar</button>
                    <button onClick={() => deleteRecord(r.uid)} className="p-2 rounded-md border text-red-600">Excluir</button>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-6 border-t pt-4">
            <h3 className="text-lg font-medium">Visão por calendário / semana</h3>
            <div className="mt-3 grid gap-4">
              {Object.keys(groups).length === 0 && <div className="text-gray-500">Sem registros para agrupar.</div>}
              {Object.entries(groups).map(([wk, list]) => (
                <div key={wk} className="p-3 border rounded-md">
                  <div className="flex items-center justify-between">
                    <div><strong>Semana de:</strong> {new Date(wk).toLocaleDateString()}</div>
                    <div><strong>Total:</strong> {formatCurrency(list.reduce((s, x) => s + Number(x.amount), 0))}</div>
                  </div>

                  <div className="mt-2 grid grid-cols-1 md:grid-cols-7 gap-2">
                    {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom'].map((d, i) => {
                      const day = new Date(wk);
                      day.setDate(day.getDate() + i);
                      const dayStr = day.toISOString().slice(0,10);
                      const dayRecords = list.filter(x => (x.date || x.createdAt).slice(0,10) === dayStr);
                      return (
                        <div key={d} className="p-2 border rounded-md min-h-[60px]">
                          <div className="text-xs font-semibold">{d} ({day.toLocaleDateString()})</div>
                          <div className="text-sm mt-1">{dayRecords.map(dr => (<div key={dr.uid} className="flex items-center justify-between"><div className="text-xs">{dr.name || dr.id}</div><div className="text-xs font-medium">{formatCurrency(dr.amount)}</div></div>))}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        <div className="md:col-span-3 bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Painel de administração</h2>
            <div className="flex items-center gap-2">
              {isAdmin ? (
                <>
                  <button onClick={adminLogout} className="px-3 py-1 border rounded-md">Sair</button>
                  <button onClick={exportCSV} className="px-3 py-1 bg-green-600 text-white rounded-md">Exportar CSV</button>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <input type="password" placeholder="senha" value={adminPassword} onChange={(e)=>setAdminPassword(e.target.value)} className="p-1 border rounded-md" />
                  <button onClick={adminLogin} className="px-3 py-1 bg-indigo-600 text-white rounded-md">Entrar</button>
                </div>
              )}
            </div>
          </div>

          {isAdmin && (
            <div className="mt-4 grid md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-md">
                <h3 className="font-semibold">Gerenciar usuários (ID → nome)</h3>
                <div className="mt-2 text-sm text-gray-500">Adicione/edite usuários para que o nome apareça automaticamente quando o ID for inserido.</div>
                <div className="mt-3 space-y-3 max-h-60 overflow-auto">
                  {Object.entries(users).map(([id,u]) => (
                    <div key={id} className="flex items-center gap-2">
                      <div className="w-20 text-sm">ID {id}</div>
                      <input value={u.firstName} onChange={(e)=> updateUser(id, { firstName: e.target.value })} className="p-1 border rounded-md flex-1" placeholder="Primeiro nome" />
                      <input value={u.lastName} onChange={(e)=> updateUser(id, { lastName: e.target.value })} className="p-1 border rounded-md flex-1" placeholder="Último nome" />
                      <button onClick={()=>removeUser(id)} className="p-1 border rounded-md text-red-600">Excluir</button>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex gap-2">
                  <input id="newUserId" placeholder="novo ID" className="p-1 border rounded-md" />
                  <input id="newUserFirst" placeholder="Nome" className="p-1 border rounded-md" />
                  <input id="newUserLast" placeholder="Sobrenome" className="p-1 border rounded-md" />
                  <button onClick={()=>{
                    const id = document.getElementById('newUserId').value.trim();
                    const first = document.getElementById('newUserFirst').value.trim();
                    const last = document.getElementById('newUserLast').value.trim();
                    if(!id) return alert('Informe ID');
                    updateUser(id, { firstName: first, lastName: last });
                    document.getElementById('newUserId').value=''; document.getElementById('newUserFirst').value=''; document.getElementById('newUserLast').value='';
                  }} className="px-3 py-1 bg-indigo-600 text-white rounded-md">Adicionar</button>
                </div>
              </div>

              <div className="p-4 border rounded-md">
                <h3 className="font-semibold">Registros (controle total)</h3>
                <div className="mt-3 max-h-72 overflow-auto">
                  {records.map(r=> (
                    <div key={r.uid} className="flex items-center gap-3 p-2 border-b">
                      <div className="flex-1">
                        <div className="text-sm font-medium">{r.name || r.id}</div>
                        <div className="text-xs text-gray-500">ID: {r.id} • {r.date}</div>
                      </div>
                      <div className="text-right mr-2">{formatCurrency(r.amount)}</div>
                      <div className="flex gap-2">
                        <button onClick={()=>{ const newDate = prompt('Nova data (YYYY-MM-DD)', r.date); if(newDate) editRecord(r.uid, { date: newDate }); }} className="p-1 border rounded-md">Editar</button>
                        <button onClick={()=>deleteRecord(r.uid)} className="p-1 border rounded-md text-red-600">Excluir</button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-3 flex gap-2">
                  <button onClick={()=>{ if(confirm('Limpar TODOS os registros?')) { setRecords([]); } }} className="px-3 py-1 border rounded-md text-red-600">Limpar registros</button>
                  <button onClick={()=>{ if(confirm('Remover todos usuários?')) { setUsers({}); } }} className="px-3 py-1 border rounded-md">Limpar usuários</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <footer className="max-w-6xl mx-auto mt-8 text-sm text-gray-500">Feito com ♥ — exemplo local. Troque a autenticação e persistência por uma API real para produção.</footer>
    </div>
  );
}
